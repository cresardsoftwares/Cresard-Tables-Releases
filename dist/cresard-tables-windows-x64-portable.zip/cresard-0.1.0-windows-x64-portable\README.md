<p align="center">
  <a href="https://desk.cresard.com/">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="assets/brand/cresard-tables-logo-dark.png">
      <img alt="Cresard Tables" src="assets/brand/cresard-tables-logo.png" width="360">
    </picture>
  </a>
</p>

<p align="center">
  <b>A fast, native, agent-drivable spreadsheet for Windows, macOS, Linux and the web.</b>
</p>

<p align="center">
  XLSX-native, Excel-familiar, written in Rust. No subscription, no licence server, no telemetry.<br>
  <i>By <a href="https://cresard.com/">Cresard Desk</a>.</i>
</p>

<p align="center">
  <img alt="Written in Rust" src="https://img.shields.io/badge/written%20in-Rust-C74E00?style=flat-square&logo=rust&logoColor=white">
  <img alt="Runs on Windows, macOS, Linux and the web" src="https://img.shields.io/badge/runs%20on-Windows%20%C2%B7%20macOS%20%C2%B7%20Linux%20%C2%B7%20Web-FD6301?style=flat-square">
  <img alt="License: MIT OR Apache-2.0" src="https://img.shields.io/badge/license-MIT%20%2F%20Apache--2.0-C74E00?style=flat-square">
  <img alt="Agent-drivable over MCP" src="https://img.shields.io/badge/agents-MCP-FD6301?style=flat-square">
</p>

<p align="center">
  <a href="#downloads">Download</a> ·
  <a href="#a-look-around">A look around</a> ·
  <a href="#why-cresard-tables">Why Cresard Tables</a> ·
  <a href="#quick-start">Quick start</a> ·
  <a href="#for-agents-mcp-cli-and-the-control-channel">For agents</a> ·
  <a href="#architecture">Architecture</a> ·
  <a href="#roadmap">Roadmap</a> ·
  <a href="#license-and-credits">License and credits</a>
</p>

<br>

<p align="center">
  <img src="docs/images/hero-sales.png" alt="Cresard Tables showing a quarterly sales dashboard: a styled table with banded rows, filter buttons, a totals row, data bars, arrow icons and sparklines, next to a clustered column chart and a pie chart" width="100%">
  <br><sub><b>Quarterly Sales Dashboard</b>: a table with a totals row, conditional formatting, sparklines and two live charts — built entirely from Cresard Tables commands (<code>File → New → Sample</code>).</sub>
</p>

## Downloads

Cresard Tables ships as a signed-free portable build: unzip it and run it. No installer, no
service, nothing written outside your own settings folder.

| Build | Download |
|---|---|
| Desktop app, Windows x64 | [`cresard-tables-windows-x64-portable.zip`](https://raw.githubusercontent.com/cresardsoftwares/Cresard-Tables-Releases/main/dist/cresard-tables-windows-x64-portable.zip) |
| Checksums | [`SHA256SUMS.txt`](https://raw.githubusercontent.com/cresardsoftwares/Cresard-Tables-Releases/main/dist/SHA256SUMS.txt) |
| Version and notes | [`version.json`](https://raw.githubusercontent.com/cresardsoftwares/Cresard-Tables-Releases/main/dist/version.json) |

The zip holds the app, the command-line tool, this README, and the licence notices.

Every download is published in **[cresardsoftwares/Cresard-Tables-Releases](https://github.com/cresardsoftwares/Cresard-Tables-Releases)**,
which holds nothing but release artefacts and their notices. Those links always point at the
newest build; `version.json` says which version that is, and `SHA256SUMS.txt` has the checksum
for every file. Verify a download before you run it:

```powershell
Get-FileHash .\cresard-tables-windows-x64-portable.zip -Algorithm SHA256
```

macOS, Linux and WebAssembly builds can be built from source with the commands under
[Quick start](#quick-start); see [`docs/distribution.md`](docs/distribution.md) for the exact
packaging steps we use.

**If the app doesn't open on Windows:** the desktop app initializes only DirectX 12 by default.
Letting wgpu also create an OpenGL instance can crash some graphics drivers (AMD's
`atio6axx.dll`) before the window appears, so the app would flash in Task Manager and quit.
`WGPU_BACKEND` overrides the default for troubleshooting (for example `dx12` or `vulkan`). In
PowerShell, from the folder containing the executable:

```powershell
$env:WGPU_BACKEND = "vulkan"
& .\cresard-tables.exe
Remove-Item Env:WGPU_BACKEND                     # restore the default for later launches
```

An explicit `gl` override can bring the driver crash back on affected systems. If DirectX 12
finds no graphics card with a driver for it, it only offers Microsoft's software renderer, which
draws every frame on the processor; in that case Cresard Tables uses OpenGL instead, without
setting anything. The log file records the choice (lines starting with `graphics:`).

## A look around

All four pictures below are the real app, captured from the Windows build.

<table>
<tr>
<td width="50%" valign="top"><img src="docs/images/budget.png" alt="A household budget with accounting number formats, red highlights for overspent categories, a green-yellow-red colour scale on the percent-used column, a totals row with a double border, and a horizontal bar chart comparing budget with actual" width="100%"><p align="center"><sub><b>Formatting.</b> Accounting formats, cell styles, conditional rules and colour scales, frozen headers and a bar chart.</sub></p></td>
<td width="50%" valign="top"><img src="docs/images/grades-formulas.png" alt="A gradebook table with averages and letter grades computed with IFS, green highlights on A grades and data bars, with the Formulas ribbon tab open showing the function library" width="100%"><p align="center"><sub><b>Formulas.</b> 500+ functions, dynamic arrays, LET and LAMBDA, structured table references.</sub></p></td>
</tr>
<tr>
<td width="50%" valign="top"><img src="docs/images/dark-sales.png" alt="The sales dashboard in dark mode: the same styled table, colour scales and charts on a dark grid and ribbon" width="100%"><p align="center"><sub><b>Dark mode.</b> The whole interface follows the system theme, or a fixed Light or Dark choice under View.</sub></p></td>
<td width="50%" valign="top"><img src="docs/images/hero-sales.png" alt="The quarterly sales dashboard with a styled table, sparklines, arrow icons and two charts" width="100%"><p align="center"><sub><b>Sample workbooks.</b> <code>File → New → Sample</code> builds sales, budget and grades workbooks in code, with no data files in the installer.</sub></p></td>
</tr>
</table>

## Why Cresard Tables

- **Familiar.** Excel's ribbon, formula bar, Name Box, sheet tabs, keyboard shortcuts, fill
  handle, point-mode formula entry with coloured references, Format Cells, Paste Special,
  conditional formatting, tables and charts. If you know Excel, you already know Cresard Tables.
- **Compatible.** XLSX is the native format: styles, themes, formulas (including dynamic arrays),
  tables, conditional formats, validation, comments, hyperlinks, charts, pictures, sparklines,
  PivotTables and print settings round-trip. CSV and TSV too.
  Excel 97-2003 `.xls` workbooks open with their values, formulas and number formats (formatting and objects not yet).
  [XLSB worksheet data can be imported](docs/xlsb-import.md), using saved values instead of formulas.
  [ODS worksheet data can be imported](docs/ods-import.md), using saved values instead of formulas.
  [Static pictures can live inside cells](docs/cell-pictures.md), fitting their size and moving with the data.
- **Capable.** A dependency-graph calculation engine with dynamic arrays and spilling,
  500+ worksheet functions plus LET, LAMBDA, MAP, REDUCE, SCAN, BYROW, BYCOL and MAKEARRAY,
  structured table references, Excel's full number-format language, sort and AutoFilter,
  data validation, outlining and subtotals.
- **Fast.** Copy-on-write workbooks (undo snapshots are nearly free), incremental recalculation,
  and a virtualised grid that only lays out what's on screen.
- **Agent-native.** Every ribbon button, menu item, dialog, keystroke and mouse gesture is a
  command that agents can run over a JSON control channel, an **MCP server**, or the CLI.
- **Everywhere.** One Rust codebase for desktop and the web. No subscription, no licence server,
  no telemetry.

## Quick start

```sh
cargo run --release -p cresard-tables                              # desktop app
cargo run --release -p cresard-tables -- --sample sales            # open a sample (sales, budget, grades)
cargo run --release -p cresard-tables -- book.xlsx                 # open a workbook
cargo run --release -p cresard-tables -- --sample sales --control 7979   # + JSON control channel
cargo xtask ci                                                     # fmt, clippy, tests, assets, layers, wasm
```

Choose Español under View → Interface language for [Spanish formula names, decimal commas, and semicolon arguments](docs/formula-input.md).
Workbooks, clipboard exchange, and programmatic APIs retain canonical English syntax.

### Web

```sh
cd apps/cresard-tables-web && trunk build --release     # → dist/web (serve it with any static server)
cd apps/cresard-tables-web && trunk serve --release     # http://127.0.0.1:8771  (?sample=sales opens a sample)
```

You need [trunk](https://trunkrs.dev) and the `wasm32-unknown-unknown` target. Open uses the
browser's file picker (dropping files works too) and Save downloads the workbook.

### Windows portable build

```powershell
cargo build --release -p cresard-tables -p cresard-tables-cli
powershell -File packaging\windows\package.ps1
```

Packaging details, the release checklist and how a build is published are in
[`docs/distribution.md`](docs/distribution.md).

### Ribbon access keys

Press and release **left Alt** on Windows/Linux, or press **F10** on any platform,
then type a sequence below one key at a time. Keytips appear on the supported Home
controls and menu items. On macOS, use F10 (Fn+F10 if required by your keyboard); Option
remains available for entering accented characters.

| Sequence after Alt/F10 | Action |
|---|---|
| `H A L` / `H A C` / `H A R` | Align left / center / right |
| `H V S` or legacy `E S` | Open Paste Special |
| `H O I` or legacy `O C A` | AutoFit selected columns |

In Paste Special, **T/V/F/C** select formats/values/formulas/comments, and **E** toggles
Transpose. **Enter** applies the selected options; **Escape** cancels the dialog.
These letters also work with Alt held on Windows and Linux.

Escape backs out one keytip level; Alt/F10 again exits keytips. Clicking, scrolling,
or switching windows cancels navigation. Access keys do not start while editing text
or using another dialog. This is initial support for these Home and legacy paths;
other ribbon commands and full mouse-free navigation remain to be implemented.

### Logs

The desktop app writes its log to standard error and to `cresard-tables.log` in the `logs` folder
next to its settings: `~/.config/cresard-tables/logs` on Linux (`$XDG_CONFIG_HOME/cresard-tables/logs`
when set), `~/Library/Application Support/Cresard Tables/logs` on macOS and
`%APPDATA%\Cresard Tables\logs` on Windows. Each start moves the previous log to `cresard-tables.1.log` and
that one to `cresard-tables.2.log`, so the log of a run that crashed survives the next start; attach
them to a bug report. A log file stops growing at 16 MiB. By default Cresard Tables' own crates log
at `info` and everything else at `warn`; `RUST_LOG` replaces that with env_logger-style
directives, e.g. `RUST_LOG=debug` or `RUST_LOG=warn,cresard_engine=debug` (a trailing `*`
matches a prefix: `cresard-tables*=debug`). Runs with `CRESARD_TABLES_NO_PREFS` set (no saved settings)
log to standard error only.

## For agents: MCP, CLI and the control channel

```sh
claude mcp add cresard-tables -- cresard-tables-cli mcp              # headless MCP server
cresard-tables-cli mcp --connect 7979                                # MCP bridged to a running window
cresard-tables-cli eval '=XLOOKUP("b",{"a","b"},{1,2})'              # → 2
cresard-tables-cli run --sample budget --cmd 'home.bold={"range":"B4:F4"}' --out budget.xlsx
cresard-tables-cli cat budget.xlsx --range B4:F15                    # aligned text table
cresard-tables-cli commands --search chart                           # every command and its params
```

The MCP server offers tools such as `read_range`, `write_range`, `set_cell`, `evaluate_formula`,
`format_range`, `insert_chart`, `create_table`, `sort_range`, `filter` and `execute_command`
(which reaches every one of Cresard Tables' commands). The desktop app's control channel adds real
pointer and keyboard input, dialogs and screenshots. See [`docs/mcp.md`](docs/mcp.md),
[`docs/cli.md`](docs/cli.md) and [`docs/control-protocol.md`](docs/control-protocol.md).

## Architecture

Cresard Tables is an engine-first Cargo workspace with enforced layering (`cargo xtask layers`). The
egui frontend is a separate crate, so the UI can be swapped without touching the engine.

| Layer | Crates |
|---|---|
| L0 | `core` (addresses, values, errors, dates, input parsing) · `numfmt` (number format codes) |
| L1 | `formula` (lexer, parser, printer, reference adjustment) · `functions` (worksheet function library) |
| L2 | `model` (workbook, sheets, copy-on-write cells, styles, tables, charts…) · `calc` (dependency graph, evaluator, dynamic arrays) · `xlsx` (XLSX, CSV, plus XLSB and ODS data import) |
| L3 | `chart` (toolkit-free chart layout and rendering) |
| L5 | `engine` (session, commands, history, clipboard, fill, sort, filter, file I/O) |
| L6 | `ui-egui` (Excel-style UI, control channel) · `mcp` (MCP server) |
| L7 | `apps/cresard-tables`, `apps/cresard-tables-cli`, `apps/cresard-tables-web` |

- **Contributor and agent rules** (clean-room, asset policy, never-crash, quality gates): [`AGENTS.md`](AGENTS.md)
- **Bundled assets:** each one is listed with its licence in [`ATTRIBUTION.md`](ATTRIBUTION.md)
- **Rebranding this fork:** the one place to change a name, colour or URL is [`docs/branding.md`](docs/branding.md)
- **Releases:** how a build is made and published is in [`docs/distribution.md`](docs/distribution.md)

## Roadmap

Cresard Tables is in **alpha**: the core workflow works end to end, but depth, fidelity and file
compatibility are still rough. It covers 89% of the Excel ribbon commands in our catalog
([`docs/parity-checklist.md`](docs/parity-checklist.md)) and 513 of Excel's 523 worksheet functions
([`docs/function-parity.md`](docs/function-parity.md)); weighted by what Excel users rely on, we
estimate it is about 50% ready for real work. Next up: XLSX fidelity on real-world files, very large
workbooks and multi-threaded recalc, chart depth, text in every script, and `.xls` import. Stage,
numbers and estimates are in [ROADMAP.md](ROADMAP.md); the ranked work list is [`docs/gaps.md`](docs/gaps.md).

## About Cresard Desk

Cresard Tables is built by **[Cresard Desk](https://cresard.com/)**. The tool it grew out of —
[GridCraft](https://github.com/storytold/gridcraft) by the ArtCraft team — is open source, and this
distribution keeps its licence, its notices and its attribution in full; see
[License and credits](#license-and-credits) and [`NOTICE`](NOTICE).

<p align="center">
  <a href="https://x.com/cresard">X</a> ·
  <a href="https://www.linkedin.com/company/cresard">LinkedIn</a> ·
  <a href="https://github.com/cresard">GitHub</a> ·
  <a href="mailto:contact@cresard.com">contact@cresard.com</a> ·
  <a href="https://desk.cresard.com/tables">desk.cresard.com/tables</a>
</p>

## License and credits

Cresard Tables is dual-licensed under [MIT](LICENSE-MIT) or [Apache-2.0](LICENSE-APACHE), at your option.
Copyright (c) 2026 Cresard Desk Team and the Cresard Tables contributors. It is a rebranded
distribution of GridCraft, Copyright (c) 2026 ArtCraft Team and the GridCraft contributors,
and both copyright notices are kept as the licence requires. Required notices are in
[NOTICE](NOTICE).

Bundled icons, images, screenshots and other assets keep their own open licences; each one is
listed with its author, source and licence in [ATTRIBUTION.md](ATTRIBUTION.md).

All UI icons are drawn in code and are original; the sample workbooks and every screenshot in
this README were made with Cresard Tables itself. Cresard Tables bundles no fonts: it uses the fonts
installed on your system.

The Cresard Desk and Cresard Tables names, the wordmark and the app icon in
[`assets/brand/`](assets/brand/) and [`assets/app-icon/`](assets/app-icon/) are trademarks of
Cresard Desk and are not covered by this licence. They may be used only unmodified, and only as
part of this repository and of Cresard Tables, under [`NOTICE`](NOTICE). Forks and modified
versions must remove them.

<sub>Microsoft, Excel and Microsoft 365 are trademarks or registered trademarks of Microsoft Corporation in the United States and/or other countries. Cresard Tables is an independent, open-source project and is not affiliated with, sponsored by or endorsed by Microsoft Corporation; these names are used only to describe the workflows it is compatible with.</sub>

<br>

<p align="center">
  <a href="https://desk.cresard.com/"><img alt="Cresard Desk" src="assets/app-icon/cresard-tables.png" width="32"></a><br>
  <sub>Made by <a href="https://cresard.com/">Cresard Desk</a>.</sub>
</p>
